﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tsueda_Brandon_CoffeeRun
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
             Brandon Tsueda
             SDI Section 01
             10/02/2018
             Coffee Run
             */

            /*Data	Sets	To	Test:
            • First	Test	– Use	the	given	array	in	3-b-i of	the	instructions	above.
            o {“coffee”,	“cappuccino”, “latte”,	“cappuccino”,	“latte”,	”	coffee”,	“cappuccino”,	
            “coffee”,	“decaf”,	“cappuccino”	}
            o Results	should	be:
            § “Order	3	number	of	Coffee.”
            § “Order	4	number	of	Cappuccino.”
            § “Order	2	number	of	Latte.”
            § “Order	1	number	of	Decaf.”

            • Second	Test	– Using	a	new	array,	does	your	code	still	work	correctly?
            o Comment	out	the	original	array,	but	leave	it	in	your	code	so	I	can	test	it.
            o Create	the	same	array	variable,	but	this	time	use	the values	below.
            o Note	that	there	are	a	different	number	of	items	in	the	array!
            o {“coffee”,	“cappuccino”,	“latte”,	“decaf”,	“decaf”,	”	cappuccino”,	“cappuccino”,	
            “coffee”,	“decaf” }
            o Results	should	be:
            § “Order	2 number	of	Coffee.”
            § “Order	3 number	of	Cappuccino.”
            § “Order	1 number	of	Latte.”
            § “Order	3 number	of	Decaf.”*/

            //Greet user and explain the program.

            Console.WriteLine("Hello, this application will simplify your drink orders and count them for you\r\nto make it a litle easier for you.");

            //Two data sets to test.
            //string[] drinks = {"coffee", "cappuccino", "latte", "cappuccino", "latte",  "coffee", "cappuccino", "coffee", "decaf", "cappuccino" };
            string[] drinks = { "coffee", "cappuccino", "latte", "decaf", "decaf", "cappuccino", "cappuccino", "coffee", "decaf"};

            //Declare variables for each drink
            int coffee = 0;
            int cappuccino = 0;
            int latte = 0;
            int decaf = 0;

            //Create loop to cycle through each drink and add them up
            for (int i = 0; i < drinks.Length; i++)
            {
                if (drinks[i] == "coffee")
                {
                    coffee++;
                }
                if (drinks[i] == "cappuccino")
                {
                    cappuccino++;
                }
                if (drinks[i] == "latte")
                {
                    latte++;
                } 
                if (drinks[i] == "decaf")
                {
                    decaf++;
                }
            }

            //Output results
            Console.WriteLine("Order {0} number of coffee.", coffee);
            Console.WriteLine("Order {0} number of cappuccino.", cappuccino);
            Console.WriteLine("Order {0} number of latte.", latte);
            Console.WriteLine("Order {0} number of decaf.", decaf);

            Console.WriteLine("Thank you for using my application!  Your calulations are complete.");
        }
    }
}
