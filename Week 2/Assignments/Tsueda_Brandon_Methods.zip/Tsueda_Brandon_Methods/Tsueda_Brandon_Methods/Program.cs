﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tsueda_Brandon_Methods
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Brandon Tsueda
             SDI Section 01
             10/10/2018
             Methods
             */

            //Problem #1 Currency Convertor

            //Ask user for input.
            Console.WriteLine("Please input the amount of euros you would like to convert today.");

            //Store input
            string euroAmount = Console.ReadLine();
            decimal euroD;

            //Validate
            while (!(decimal.TryParse(euroAmount, out euroD)))
            {
                Console.WriteLine("Please input the amount of euros you would like to convert today.");
                euroAmount = Console.ReadLine();
            }
            decimal methodReturn = converter(euroD);

            //Output results
            Console.WriteLine("{0} euros converted to dollars ${1}", euroD, methodReturn );

            /* Data	Sets	To	Test	
           o Euros – 5.50
           § Results - “5.50 euros converted to dollars is $6.38”
           o Euros – 15.32
           § Results - “15.32 euros converted to dollars is $17.77”
           o Euros – 249.58
           § Results - “249.58 euros converted to dollars is $289.51”
           o Test one of your own and put all 3 of these test values in a multi-lined comment
           at the end of your code.*/

            Console.ReadKey();
            Console.Clear();

            //--------------------------------------------------------------------------------------------------------------------------
            //Problem #2 Astronomical

            //Store planets and percentages
            string[] planets = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune" };
            double[] percentages = { 38, 91, 100, 38, 237, 93, 92, 112 };
            
            //Ask user for input
            Console.WriteLine("Please tell me your current earth weight.");

            //Store input
            string earthWeight = Console.ReadLine();
            double earthConvert;

            //Validate
            while (!(double.TryParse(earthWeight, out earthConvert)))
            {
                Console.WriteLine("Please input your weight on earth.");
                earthWeight = Console.ReadLine();
            }


            //Prompt user for planet
            Console.WriteLine("Please choose from these planets to compare your weight.");
            Console.WriteLine("1. Mercury");
            Console.WriteLine("2. Venus");
            Console.WriteLine("3. Earth");
            Console.WriteLine("4. Mars");
            Console.WriteLine("5. Jupiter");
            Console.WriteLine("6. Saturn");
            Console.WriteLine("7. Uranus");
            Console.WriteLine("8. Neptune");

            //Store input
            string planetChoice = Console.ReadLine();
            int planetChoiceInt;

            //Validate
            while (!(int.TryParse(planetChoice, out planetChoiceInt)) || planetChoiceInt < 1 || planetChoiceInt > 8 )
            {
                Console.WriteLine("Please a number between 1 and 8");
                planetChoice = Console.ReadLine();
            }

            //Subtract 1 from user choice to get array index number
            double planetWeightPercent = percentages[planetChoiceInt - 1];
            string planetSelect = planets[planetChoiceInt - 1];

            //Call method
            double newWeight = convert(earthConvert, planetWeightPercent);

            //Output results
            Console.WriteLine("On Earth you weigh {0} lbs, but on {1} you would weigh {2} lbs.", earthConvert, planetSelect, newWeight);

            /*Data Sets    To Test
            o Astronaut’s Weight – 160 Planet Choice -6
            § Results - “On Earth you weigh 160 lbs, but on Saturn you would weigh
            148.8 lbs.”
            o Astronaut’s Weight – 210 Planet Choice -9 (Re - prompt because not a valid
            choice) , New Choice -5
            § Results - “On Earth you weigh 210 lbs, but on Jupiter you would weigh
            491.4 lbs.”
            o Astronaut’s Weight – 245 Planet Choice -9 (Re - prompt because not a valid
            choice) , New Choice -7
            § Results - “On Earth you weigh 245 lbs, but on Uranus you would weigh
            225.4 lbs.”
            o Test one of your own and put all 3 of these test values in a multi-lined comment
            at the end of your code.*/

            Console.ReadKey();
            Console.Clear();

            //------------------------------------------------------------------------------------------------------------------------

            //Problem #3 Subtraction

            //Create Arrays
            int[] firstArray = { 10, 20, 30, 40, 50, 60, 70, 80, 90 };
            int[] secondArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            int arrayLength = firstArray.Length;
            int[] thirdArray = new int[arrayLength];

            //Method call
            thirdArray = subtractionArray(firstArray, secondArray);

            for (int i = 0; i < arrayLength; i++)
            {
                Console.WriteLine("{0} - {1} = {2}", firstArray[i], secondArray[i], thirdArray[i]);
            }

            /*§ Data Sets    To Test
            o First Array   – [4,   65, 32, 42, 12] Second Array	– [1,   2,  5,  6,  9]
            § Results
            • “4-1	is	3.”
            • “65-2	is	63.”
            • “32-5	is	27.”
            • “42-6	is	36.”
            • “12-9	is	3.”
            o First Array	– [54,  125,    96, 72, 45, 67] Second Array	– [87,  122,    145,    65, 3,  800]
            § Results
            • “54-87	is	-33.”
            • “125-122	is	3.”
            • “96-145	is	-49.”
            • “72-65 is	7.”
            • “45-3 is	42.”
            • “67-800 is	-733.”
             o First Array	– 10, 20, 30, 40, 50, 60, 70, 80, 90] Second Array	– [1, 2, 3, 4, 5, 6,7 ,8 ,9]
            § Results
            • “10-1	is  9.”
            • “20-2 is 18.”
            • “30-3	is 27.”
            • “40-4 is 36.”
            • “50-5 is 45.”
            • “60-6 is 54.”
            • “70-7 is 63.”
            • “80-8 is 72.”
            • “90-9 is 81.”
            o Now   that you tested these	2	arrays,	create one of your    own to  test and turn	in.
                Put all of these   test values	in	a multi-lined comment at the end of  your code.*/


        }
        //Methods
        public static decimal converter(decimal euroD)
        {
            return Math.Round(euroD * 1.16M, 2);
        }
        //------------------------------------------------------------------------------
        public static double convert(double earthConvert, double planetWeightPercent)
        {
            double newWeight = (earthConvert / 100 * planetWeightPercent);
            return newWeight; 
        }
        //------------------------------------------------------------------------------
        public static int[] subtractionArray(int[] firstArray, int[] secondArray)
        {
            //Variable to store the size of the first array.
            int tempArraySize = firstArray.Length;

            //New array to equal the size of he first array.
            int[] fourthArray = new int[tempArraySize];

            //Subtract secondArray from firstArray
            for (int i = 0; i < tempArraySize; i++)
            {
                fourthArray[i] = firstArray[i] - secondArray[i];
            }

            return fourthArray;
        }
    }
}
