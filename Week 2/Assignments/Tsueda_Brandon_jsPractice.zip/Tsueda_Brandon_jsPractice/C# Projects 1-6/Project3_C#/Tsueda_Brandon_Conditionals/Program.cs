﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tsueda_Brandon_Conditionals
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Brandon Tsueda
             SDI Section 01
             10/1/2018
             Conditionals
             */
             /*
            //Problem #1 Hit the Jackpot
            //Data	Sets	to	Test:
            (Note that data sets are not the only numbers that should work with your code, but you	
            need to be sure to test these plus 1 of your own for the test value section.)
            o Winnings = 20000, Payment Option= “A”
            § Results = “Your winnings of $20,000 will be paid in 20 payments of $1,000	
            a year.”

            o Winnings = 100000.50, Payment Option=	“L”
            § Results = “Your winnings of $100,000.50 as a one-time lump some	
            payment is $85,000.425.”

            o Winnings = 65000000.99, Payment Option= “a” Note the lowercase letter!
            § Results = “Your winnings of $65,000,000.99 will be paid in 20 payments	
            of $3,250,000.0495 a year.”

            *Winnings = 5000, Payment Option = "L"
            * Results = Your winnings of $5,000.00 as a one-time lump some
            pament is $4.250.00.
            
            o Test One Of Your Own. All 4 of these tests must be in your code in a multi-lined	
            comment. They must not be copy and pasted and they must	match your	
            programs output.*/

            
            //Congratulate user and prompt for key press.
            Console.WriteLine("Congratulations! You have just won the lotery! We will now calculate how much your actual total");	
            Console.WriteLine("winnings will be. You have two options; the first option is a lump sum one-time payment. If you");
            Console.WriteLine("do this you will only receive 85 % of your winnings. The second option is to take 20 annual");
            Console.WriteLine("payments but you take the full amount.");
            Console.WriteLine("Please press any key to continue");
            Console.ReadKey();

            //Prompt user for amount won.
            Console.WriteLine("So please tell me how much you won?");
            string cashValue = Console.ReadLine();

            decimal.TryParse(cashValue, out decimal actualCash);

            //Thank user and prompt for option one or two.
            Console.WriteLine("Thank you, and congratulations on that amount.");
            Console.WriteLine("Now Please tell me which option you would like to proceed with to receive your winnings.");
            Console.WriteLine("If you would like to receive your winnings in own big lump sum please type L and hit enter.");
            Console.WriteLine("Otherwise, please type A to receive your winnings in annual payments.");

            //Store user input converts string to upper case letters
            string decision = Console.ReadLine().ToUpper();

            decimal lumpPercent = .85M;
            decimal annualPercent = 20M;

            //Validate user input and store
            if (decision == "L")
            {
                decimal lumpSum = (actualCash * lumpPercent);
                Console.WriteLine("Your	winnings	of	$"+ actualCash +" as	a	one-time	lump	some	payment	is	$" + lumpSum + "!");
            }

            else if (decision == "A")
            {
                decimal annualSum = (actualCash / annualPercent);
                Console.WriteLine("Your winnings of $" + actualCash + " will be paid in 20 payments of $" + annualSum + " a year.");
            }

            else
            {
                Console.WriteLine("Please enter either A or L");
                decision = Console.ReadLine().ToUpper();
            }

            //Reset for next problem.
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
            Console.Clear();

            //------------------------------------------------------------------------------------------------------

            //Problem# 2 Lets Make a Deal!

            /*Data	Sets	to	Test:
            o Number of	items in bulk pack = 50, Cost of bulk pack = 100.00, Cost of individual	
            item = 4.50, Coupon Value = 1.00 off
            § Result – The cost of 1 item in the bulk pack is $2.00, which is cheaper	
            than the cost of the individual item with coupon, which is $3.50. Buy the	
            bulk pack!”
            
            o Number of items in bulk pack = 20, Cost of bulk pack = 80.50, Cost of individual	
            item = 6.25,Coupon Value = 2.25 off
            § Result – “The cost of 1 item using a coupon is $4.00, which is cheaper	
            than the cost of the individual item from the bulk pack, which is $4.025.			
            Buy the individual item and use the coupon!”
            
            *Number of items in bulk pack = 100.00, Cost of bulk pack = 10.00, Cost of individual	
            item = 5.00,Coupon Value = 1.50 off
            § Result – “The cost of 1 item using a coupon is $.10, which is cheaper	
            than the cost of the individual item from the bulk pack, which is $3.50.			
            Buy the individual item and use the coupon!”

            o Test One Of Your Own. All 3 of these tests must be in your code in a multi-lined	
            comment. They must not be copy and pasted and they must match your	
            programs output.
            */
            
            //Greet user and prompt for variables.
            Console.WriteLine("Let's Make a Deal!");
            Console.WriteLine("Please tell me the number of items in the bulk pack.");

            //Store input and convert
            string bulk = Console.ReadLine();

            decimal.TryParse(bulk, out decimal bulkItems);

            //Thank user prompt for next variable
            Console.WriteLine("Thank you, now please tell me the cost of the bulk pack.");

            //Store input and convert
            string bulkTwo = Console.ReadLine();

            decimal.TryParse(bulkTwo, out decimal bulkAmount);

            //Thank use and prompt for next variable
            Console.WriteLine("Thank you, now please tell me the price of the single item.");

            //Store input and convert.
            string singleItem = Console.ReadLine();

            decimal.TryParse(singleItem, out decimal singleAmount);

            //Thank user and prompt for last variable.
            Console.WriteLine("Thank you, lastly please tell me how much your coupon is good for.");

            //Store user input and convert
            string couponOne = Console.ReadLine();

            decimal.TryParse(couponOne, out decimal couponDiscount);

            //Calculate totals
            decimal singleDiscount = (singleAmount - couponDiscount);
            decimal bulkSingles = (bulkAmount / bulkItems);


            //Output results for user
            if (bulkSingles < singleDiscount)
            {
                Console.WriteLine("The cost of 1 item in the bulk pack is $" + bulkSingles + ", which is cheaper than the cost");
                Console.WriteLine("of the individual item with coupon, which is $" + singleDiscount + ". Buy the bulk pack!");
            }

            else 
            {
                Console.WriteLine("The cost of 1 item using a coupon is $" + singleDiscount + ", which is cheaper than the cost");	
                Console.WriteLine("of the individual item from the bulk pack, which is $" + bulkSingles + ". Buy the individual");
                Console.WriteLine("item and use the coupon!");
            }  


            //Reset for next problem.
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
            Console.Clear();
            

            //-----------------------------------------------------------------------------------------------------------------------

            //Problem# 3 Pumpkin Patch Pickers

            /*• Data	Sets	to	Test:
            o Pumpkin	weight	=	4.5
            § Result - “Your	pumpkin	of	4.5	lbs.	costs	$4.50.”
            
            o Pumpkin	weight	=	10
            § Result - “Your	pumpkin	of	10	lbs.	costs	$9.00.”
            
            o Pumpkin	weight	=	20.75
            § Result - “Your	pumpkin	of	20.75	lbs.	costs	$16.60.”
            
            o Pumpkin	weight	=	40
            § Result - “Your	pumpkin	of	40	lbs.	costs	$28.00.”
            
            o Pumpkin	weight	=	100
            § Result - “Your	pumpkin	of	100	lbs.	costs	$60.00.”
            
            o Pumpkin	weight	=	150.30
            § Result - “Your	pumpkin	of	150.30	lbs.	costs	$75.15.”
            
            o Pumpkin	weight	=	200
            § Result - “Your	pumpkin	of	200	lbs.	costs	$100.00.”
             
             */


            
            //Prompt user for weight
            Console.WriteLine("Please tell me the weight of your pumpkin.");

            //Store and convert to decimal
            string pumpkinOne = Console.ReadLine();
            decimal.TryParse(pumpkinOne, out decimal pumpkinWeight);

            if (pumpkinWeight <= 5.5M)
            {
                decimal weightOne = (pumpkinWeight * 1.00M);
                Console.WriteLine("Your	pumpkin	of " + pumpkinWeight + "lbs. costs	$" + weightOne + ".");
            }
            else if (pumpkinWeight <= 10.75M)
            {
                decimal weightTwo = (pumpkinWeight * 0.90M);
                Console.WriteLine("Your	pumpkin	of " + pumpkinWeight + "lbs. costs	$" + weightTwo + ".");
            }
            else if (pumpkinWeight <= 25M)
            {
                decimal weightThree = (pumpkinWeight * .80M);
                Console.WriteLine("Your	pumpkin	of	" + pumpkinWeight + " lbs. costs $" + weightThree + ".");
            }
            else if (pumpkinWeight <= 50M)
            {
                decimal weightFour = (pumpkinWeight * .70M);
                Console.WriteLine("Your	pumpkin	of	" + pumpkinWeight + " lbs. costs $" + weightFour + ".");
            }
            else if (pumpkinWeight <= 100M)
            {
                decimal weightFive = (pumpkinWeight * .60M);
                Console.WriteLine("Your	pumpkin	of " + pumpkinWeight + " lbs. costs $" + weightFive + ".");
            }
            else if (pumpkinWeight > 100M)
            {
                decimal weightSix = (pumpkinWeight * .50M);
                Console.WriteLine("Your	pumpkin	of " + pumpkinWeight + " lbs. costs $" + weightSix + ".");
            }

            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
            Console.Clear();

            //-----------------------------------------------------------------------------------------------------------

            //Problem# 4 Loyalty Card

            /*• Data	Sets	to	Test:
            o First Item Cost - $45.50, Second Item Cost - $75.00, Preferred Member – “yes”
            § Results - “Your total purchase is $102.425, which includes your 15%	
            discount.”
            o First	Item Cost - $23.00, Second Item Cost - $44.25, Preferred Member – “yes”
            § Results - “Your total purchase is $67.25.”
            
            o First	Item Cost - $50.00, Second Item Cost - $15.00, Preferred Member – “yes”
            § Results - “Your total purchase is $55.25.”

            o Test One Of Your Own. All 4 of these tests must be in	your code in a multi-lined	
            comment. They must not be copy and pasted and they must match your	
            programs output.*/

            //Prompt user for the price of the first item.

            Console.WriteLine("Please tell me the cost of your first item");

            //Store and convert
            string firstItem = Console.ReadLine();
            decimal firstPrice;
            while (!(decimal.TryParse(firstItem, out firstPrice)))
            {
                Console.WriteLine("Please enter a number");
                firstItem = Console.ReadLine();
            }

            

            //Prompt user for the price of the second item.
            Console.WriteLine("Please tell me the cost of your second item now.");

            //Store and convert
            string secondItem = Console.ReadLine();
            decimal secondPrice;
            while (!(decimal.TryParse(secondItem, out secondPrice)))
            {
                Console.WriteLine("Please enter a number");
                secondItem = Console.ReadLine();
            }

            //Add items
            decimal itemTotal = (secondPrice + firstPrice);

            //Prompt user for loyalty member or not.
            Console.WriteLine("Now, please tell me if you are a Loyalty member.");

            //Store input
            string memberStatus = Console.ReadLine();

            //Validate yes and no
            while (memberStatus != "YES" && memberStatus != "NO" && memberStatus != "yes" && memberStatus != "no")
            {
                Console.WriteLine("Please enter Yes or No");
                memberStatus = Console.ReadLine();
            } 
            //Create conditional

            if (memberStatus == "YES" || memberStatus == "yes") 
            {
                //decimal memberDiscount = (.15M);
                decimal costDiscount = (itemTotal) - (itemTotal * 0.15M);
                Console.WriteLine("Your total purchase is $" + costDiscount + ", which includes	your 15% discount.");
            }

            else // (memberStatus == "NO")
            {
                Console.WriteLine("Your total purchase is $" + itemTotal + ".");
            }
            

        }
    }
}
