﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tsueda_Brandon_LogicLoops
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Brandon Tsueda
             SDI Section 01
             9/26/2018
             Logic Loops
             */

            //Problem	#1 – Logical	Operators:	Making	The	Grade

            //Greet user 
            Console.WriteLine("Hello and welcome to the grading scale to help you determine if you have passed!");

            //Create Array to hold inputs
            int[] grades = new int[2];

            //Prompt user for first grade
            Console.WriteLine("To begin please tell me the value of your first grade.");

            //Store validate and convert user input.
            string gradeOne = Console.ReadLine();
            while (!(int.TryParse(gradeOne, out grades[0])))
            {
                Console.WriteLine("Pleasee enter a whole number.");
                gradeOne = Console.ReadLine();

            }

            //Prompt user for next input.
            Console.WriteLine("Perfect, now please tell the value of your second grade.");

            //Store validate and convert user input, then output results.
            string gradeTwo = Console.ReadLine();
            while (!(int.TryParse(gradeTwo, out grades[1])))
            {
                Console.WriteLine("Pleasee enter a whole number.");
                gradeTwo = Console.ReadLine();
            }
                if (grades[0] >= 70 && grades[1] >= 70)
            {
                Console.WriteLine("Congrats, both grades are passing!");
            }
            else
            {
                Console.WriteLine("One or more grades are failing, try harder  next time!");    
            }

            //Reset for next problem.
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
            Console.Clear();

            //Problem	#2 – Logical	Operators:	Brunch	Bunch

            //Greet user and give first prompt.
            Console.WriteLine("Hello and thank you coming to JJ's Diner!");
            Console.WriteLine("To figure out pricing what is your age?");

            //Store validate, and convert input.
            string age = Console.ReadLine();
            int customerAge;

            while (!(int.TryParse(age, out customerAge)))
            {
                Console.WriteLine("Please enter a whole number");
                age = Console.ReadLine();
            }
            if (customerAge >= 55 || customerAge <= 10)
            {
                Console.WriteLine("Your cost    for brunch today   is $10.00");
            }
            else
            {
                Console.WriteLine("Your cost for brunch today is $15.00");
            }

            //Reset for next problem.
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
            Console.Clear();

            //Problem	#3 – For	Loop:	Add	Them	Up

            //Greet user.
            Console.WriteLine("Hello, and welcome to the Movie Counter!");
            
            //Prompt user for first value.
            Console.WriteLine("Please, tell me how many DVD's you have.");

            //Convert, validatem and store input.
            string dvd = Console.ReadLine();
            int dvdNumb;

            while (!int.TryParse(dvd, out dvdNumb))
            {
                Console.WriteLine("Please enter a whole number");
                dvd = Console.ReadLine();
            }

            //Prompt user for second value.
            Console.WriteLine("Please, tell me how many Blue Rays's you have.");

            //Validate, convert, and store user input.
            string bluRay = Console.ReadLine();
            int blueNumb;

            while (!int.TryParse(bluRay, out blueNumb))
            {
                Console.WriteLine("Please enter a whole number");
                bluRay = Console.ReadLine();
            }

            //Promt user for last value.
            Console.WriteLine("Please, tell me how many Ultra Violet's you have.");

            //Validate, convert, and store input.
            string ultraV = Console.ReadLine();
            int ultraNumb;

            while (!int.TryParse(ultraV, out ultraNumb))
            {
                Console.WriteLine("Please enter a whole number");
                ultraV = Console.ReadLine();
            }

            //Create an Array to store all given iputs.
            int[] movies = new int[] { dvdNumb, blueNumb, ultraNumb };

            int totalMovie = 0;

            //Output depends on total.  If over 100 fist output, else if under 100 second output.
            foreach(int allMovies in movies)
            {
                totalMovie = totalMovie + allMovies;
            }

            if(totalMovie >= 100)
            {
                Console.WriteLine("Wow,	I am impressed with	your collection	of {0} movies!", totalMovie);
            }
            else if(totalMovie < 100)
            {
                Console.WriteLine("You have a total of {0}	movies in your collection.", totalMovie);
            }

            //Reset for next problem.
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
            Console.Clear();

            //Problem	#4 – While	Loop:	Cha-Ching!

            //Greet user and prompt for initial value.
            Console.WriteLine("Thank you for visiting GameStop! How much is on your gift card?");

            //Validate, convert and store input.
            string card = Console.ReadLine();
            decimal cardAmt;

            while (!(decimal.TryParse(card, out cardAmt)))
            {
                Console.WriteLine("Please enter a dollar amount.");
            }
            //Set starting number for purchase.
            int purchaseNumb = 1;
            //Set conditional, keep running until card balance is below 0.
            while (cardAmt > 0)
            {
                //Prompt user for purchases, and keep adding prompts till balance is empty.
                Console.WriteLine("Please enter purchase " + purchaseNumb +" amount");
                purchaseNumb++;

                //Validate, convert and store input.
                string nextAmt = Console.ReadLine();
                decimal purchaseAmount;

                while (!(decimal.TryParse(nextAmt, out purchaseAmount)))
                {
                    Console.WriteLine("Please enter a dollar amount.");
                    nextAmt = Console.ReadLine();
                }

                //Subtract purchase from balance.
                cardAmt -= purchaseAmount;

                //Set outputs for each purchase till balance is less than 0.  After balance hits 0 or less output else statement.
                if (cardAmt > 0)
                {
                    Console.WriteLine("With your current purchase of  $" + purchaseAmount + ", you can still spend $" + cardAmt + ".");
                }
                else
                {
                    Console.WriteLine("With your last purchase of $" + purchaseAmount + ",	you have used your gift card up and still owe $" + cardAmt + ".");
                }
            }


        }
    }
}
