﻿using System;
namespace Tsueda_Brandon_FinalProject
{
    //declare variablesf ro character stats and info

    public class Player
    {
    }
}
