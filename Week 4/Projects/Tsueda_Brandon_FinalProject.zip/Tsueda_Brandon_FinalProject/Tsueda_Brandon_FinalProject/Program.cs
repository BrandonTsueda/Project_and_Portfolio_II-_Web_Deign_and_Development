﻿using System;

namespace Tsueda_Brandon_FinalProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //define string for users selection
            //define bool program running
            string usersSelection;
            bool programRunning = true;

            //while loop to run until the user chooses to exit
            while (programRunning)
            {
                // Menu
                //1. Start Game
                //2. Create Character
                //3. Load Charater
                //4. Exit
                Console.WriteLine("~~~~Game Menu~~~~\n\n" +
                    "   1. Start Game\n" +
                    "   2. Create Character\n" +
                    "   3. Load Character\n" +
                    "   4. Exit\n\n");
                Console.Write("Please select 1 - 4: ");

                //store user input
                usersSelection = Console.ReadLine();

                //switch statement with cases for each selection
                switch (usersSelection)
                {
                    //Start Game - Run the game if there is a character loaded
                    case "1":
                        {
                            Console.WriteLine("~~~~Start Game~~~~\n" +
                                " ");
                            break;
                        }

                    //Create character - prompt user for values needed to create the character
                    case "2":
                        {
                            Console.WriteLine("~~~~Create Character~~~~");
                            break;
                        }

                    //Load character - display a list of generated characters for the user to load and select
                    case "3":
                        {
                            Console.WriteLine("~~~~Load Character~~~~");
                            break;
                        }

                    //exit program
                    case "4":
                        {
                            Console.WriteLine("Now Exitting Game");
                            programRunning = false;
                            break;
                        }

                    //display validation message and prompt the user again
                    default:
                        {
                            Console.WriteLine("Please make a valid selection...");
                            break;
                        }
                }
            }
        }

        //Method for game actions
    }
}
