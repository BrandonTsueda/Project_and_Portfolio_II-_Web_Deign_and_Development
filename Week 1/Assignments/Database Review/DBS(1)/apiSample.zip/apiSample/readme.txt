Sample API Read me. 

1. You must have MAMP installed and running. 

2. Copy this entire directory to your htdocs directory.

3. Import the file, weather.php, into MySQL. It is a SQL Dump.
If you are using Sequel Pro, create a new database called “SampleAPIData”.
Drag the file into the Query window and click run all.

4. Test the API by opening the following URL in your browser

http://localhost:8888/apiSample/weather.php?city=Chicago
