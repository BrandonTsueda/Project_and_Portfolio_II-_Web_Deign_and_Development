﻿using System;
namespace Tsueda_Brandon_DbdReview
{
    public class Validation
    {
        public static string ValidateString(string s)
        {
            Console.WriteLine(s);
            string response = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(response))
            {
                Console.WriteLine("Please do not leave this empty...");
                response = Console.ReadLine();
            }
            return response;
        }
    }
}
