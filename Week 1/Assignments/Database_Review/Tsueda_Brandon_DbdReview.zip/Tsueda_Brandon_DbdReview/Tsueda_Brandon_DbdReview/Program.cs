﻿using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using MySql.Data.MySqlClient;

namespace Tsueda_Brandon_DbdReview
{
    class Program
    {
        //Declare MySqlConnection
        MySqlConnection conn = null;

        //global variable
        string usersCity;

        static void Main(string[] args)
        {
            //Create an instance of Program
            Program instance = new Program();

            //making an instance of MySqlConnection
            instance.conn = new MySqlConnection();

            //making an instance of Connect
            instance.Connect();

            //declaring MySqlDataReader
            MySqlDataReader reader = null;

            //string validation for the users response
            instance.usersCity = Validation.ValidateString("Please enter a city: ");

            //query statement
            string stm = "SELECT temp, pressure, humidity FROM weather WHERE city = @city LIMIT 1";// added limit one because multiple entries found for same city " Example Dallas"

            //preparing sql statement
            MySqlCommand cmd = new MySqlCommand(stm, instance.conn);

            //setting the value of @city to usersCity
            cmd.Parameters.AddWithValue("@city", instance.usersCity);

            //execute the SQL command
            reader = cmd.ExecuteReader();

            //if city returns data from the database data will be displayed via terminal
            if (reader.HasRows == true)
            {

                while (reader.Read())
                {
                    Console.WriteLine($"City: {instance.usersCity}\n" +
                        $"Tempurature: {reader.GetDecimal(0)}\n" +
                        $"Pressure: {reader.GetDecimal(1)}\n" +
                        $"Hummidity: {reader.GetDecimal(2)}\n");
                }
            }

            //else to write to console for no data
            else
            {
                Console.WriteLine("The city selected has no data available...");
            }
            
        }


        void BuildConnectionString()
        {
            //for mac connection
            string ip = "127.0.0.1";

            //for windows connection - uncomment for windows
            /* using (StringReader reader = new StringReader("c:/VFW/connection.txt"))
             {
                 //reads ip address from outside file for Widnows users
                 ip = reader.ReadLine();
             }*/

            //builds string connection
            string connString = $"server={ip};";
            connString += "userid=root;";
            connString += "password=root;";
            connString += "database=SampleAPIData;";
            connString += "port=8889";

            conn.ConnectionString = connString;
        }

        //Calls to BuildConnectionString
        void Connect()

        {
            //method to build string for connection
            BuildConnectionString();

            //try to initiate the connection
            try

            {
                //if connection successful print out success message
                conn.Open();
                Console.WriteLine("Connection was successful");

            }

            //catch exception and output exception message to console
            catch (MySqlException err)
            {
                string msg = "";
                switch (err.Number)
                {
                    case 0:

                        {

                            msg = err.ToString();

                            break;
                        }

                    case 1042:

                        {

                            msg = $"Can't resolve host address. \n{conn.ConnectionString}";

                            break;
                        }

                    case 1045:

                        {

                            msg = "Invalid username/password";

                            break;

                        }

                    default:

                        {

                            msg = err.ToString();

                            break;

                        }

                }

                Console.WriteLine(msg);

            }

        }

    }
}
